import React from "react";
const UserType = () => {
  return (
    <div>
        <input type="radio" name="" id="" />
    </div>
  )
};
export default UserType;
