import React from "react";

function Navbar(props) {
  return (
    <div className="fixed top-0 left-0 w-full bg-gray-900 text-gray-400">
      <div className="px-[10%]">
        <div className="flex justify-between items-center">
          <div className="cursor-pointer">LOGO</div>
          <div className="flex gap-x-3">
            <div className="uppercase py-4 px-3 text-[25px] cursor-pointer hover:bg-gray-400 hover:text-gray-900 font-normal">
              Home
            </div>
            <div className="uppercase py-4 px-3 text-[25px] cursor-pointer hover:bg-gray-400 hover:text-gray-900 font-normal">
              Movies
            </div>
            <div className="uppercase py-4 px-3 text-[25px] cursor-pointer hover:bg-gray-400 hover:text-gray-900 font-normal">
              CELEBRITIES
            </div>
            <div className="uppercase py-4 px-3 text-[25px] cursor-pointer hover:bg-gray-400 hover:text-gray-900 font-normal">
              news
            </div>
            <div className="uppercase py-4 px-3 text-[25px] cursor-pointer hover:bg-gray-400 hover:text-gray-900 font-normal">
              COMMUNITY
            </div>
          </div>
          <div className="flex gap-x-3 uppercase text-[25px] cursor-pointer font-normal text-white">
            <a href="/login" className="py-4 px-3">Login</a>
            <div className="py-4 px-3">
              <a href="/register" className="bg-orange-400 rounded-full px-4">Sign Up</a>
            </div>
          </div>
        </div>
        <div></div>
      </div>
    </div>
  );
}

export default Navbar;
